# ─────────────────────────────────────────────────────────────────────────────
#  tools.py  –  Custom tools for the Digital Twin agent
#
#  WHAT ARE TOOLS?
#  An LLM by itself can only generate text — it can't browse the web,
#  do math, or look up facts. "Tools" are Python functions that the agent
#  can choose to call when it needs to DO something, not just say something.
#
#  HOW THE AGENT USES TOOLS:
#   User: "What's 15% of $240?"
#   Agent thinks: "I should use the calculator tool for this"
#   Agent calls:  calculator("240 * 0.15")
#   Tool returns: "36.0"
#   Agent replies: "15% of $240 is $36."
#
#  Each tool is a Python function wrapped with @tool decorator.
#  The docstring is CRITICAL — the LLM reads it to decide WHEN to use the tool.
# ─────────────────────────────────────────────────────────────────────────────

import math
import re
import wikipedia
from duckduckgo_search import DDGS
from langchain.tools import tool
from langchain_community.vectorstores import FAISS

import config


# ─── Tool 1: Calculator ───────────────────────────────────────────────────────

@tool
def calculator(expression: str) -> str:
    """
    Use this tool to perform mathematical calculations.
    Input should be a valid Python math expression like:
    '2 + 2', '15 * 0.18', 'sqrt(144)', '2 ** 10', '(100 - 20) / 4'
    Returns the numerical result as a string.
    """
    # We evaluate the expression safely using Python's built-in eval().
    # We restrict the available names to only math functions for security.
    # This prevents someone from running os.system("rm -rf /") via the calculator.

    # Build a safe namespace with math functions
    safe_names = {
        # basic math functions from the `math` module
        "sqrt": math.sqrt,
        "log": math.log,
        "log10": math.log10,
        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,
        "pi": math.pi,
        "e": math.e,
        "abs": abs,
        "round": round,
        "pow": pow,
        "floor": math.floor,
        "ceil": math.ceil,
    }

    # Remove characters that shouldn't appear in a math expression
    # This is an extra safety layer
    cleaned = re.sub(r"[^0-9+\-*/().%, a-z_]", "", expression.lower())

    try:
        # eval() executes the expression string as Python code
        # __builtins__={} disables ALL built-in functions (like open, print, etc.)
        result = eval(cleaned, {"__builtins__": {}}, safe_names)
        return str(round(float(result), 6))
    except ZeroDivisionError:
        return "Error: Division by zero"
    except Exception as e:
        return f"Error: Could not evaluate '{expression}'. Make sure it's a valid math expression. ({e})"


# ─── Tool 2: Web Search ───────────────────────────────────────────────────────

@tool
def web_search(query: str) -> str:
    """
    Use this tool to search the internet for current information,
    recent news, prices, weather, events, or anything that might
    be outside the knowledge base. Input should be a clear search query.
    Returns a summary of the top search results.
    """
    try:
        # DDGS = DuckDuckGo Search client
        # It's completely free — no API key needed!
        with DDGS() as ddgs:
            # .text() returns a generator of result dicts
            # Each result has: title, href (URL), body (snippet)
            results = list(ddgs.text(query, max_results=4))

        if not results:
            return "No results found for that query. Try rephrasing."

        # Format results into a readable block for the LLM
        formatted = []
        for i, r in enumerate(results, 1):
            formatted.append(
                f"Result {i}: {r['title']}\n"
                f"Source: {r['href']}\n"
                f"Summary: {r['body']}\n"
            )

        return "\n".join(formatted)

    except Exception as e:
        return f"Web search failed: {e}. Please try again."


# ─── Tool 3: Wikipedia ───────────────────────────────────────────────────────

@tool
def wikipedia_search(topic: str) -> str:
    """
    Use this tool to look up factual information, definitions,
    historical facts, or explanations of concepts from Wikipedia.
    Input should be the name of a person, place, concept, or topic.
    Returns a concise summary from Wikipedia.
    """
    try:
        # wikipedia.summary() fetches the first few sentences of the article.
        # sentences=5 limits the response to keep it concise.
        # auto_suggest=True handles minor typos (e.g., "Pythn" → "Python")
        summary = wikipedia.summary(topic, sentences=5, auto_suggest=True)
        return f"Wikipedia – {topic}:\n{summary}"

    except wikipedia.exceptions.DisambiguationError as e:
        # This happens when the topic is ambiguous (e.g., "Python" = snake OR language)
        # e.options gives possible matches
        options = e.options[:5]  # show first 5 options
        return (
            f"'{topic}' is ambiguous. Did you mean one of these?\n"
            + "\n".join(f"  - {opt}" for opt in options)
            + "\nPlease retry with a more specific term."
        )

    except wikipedia.exceptions.PageError:
        return f"No Wikipedia page found for '{topic}'. Try a different search term."

    except Exception as e:
        return f"Wikipedia lookup failed: {e}"


# ─── Tool 4: Resume / Knowledge Base Search (RAG) ────────────────────────────

def create_resume_search_tool(retriever):
    """
    Factory function that creates a resume search tool tied to the
    RAG retriever we built in rag.py.

    We use a factory (a function that returns a function) because
    the @tool decorator needs a plain function, but we need to
    "bake in" the retriever object.

    Args:
        retriever: A LangChain Retriever from get_retriever()

    Returns:
        A LangChain tool that searches the resume vector store
    """

    @tool
    def resume_search(query: str) -> str:
        """
        Use this tool to answer ANY question about the person's background,
        education, skills, work experience, projects, certifications,
        contact information, or anything else from their resume or personal bio.
        Always use this tool when someone asks who you are, what you do,
        your qualifications, or anything personal about you.
        Input: a natural language question about the person.
        Returns: relevant excerpts from the resume.
        """
        try:
            # retriever.invoke() does the similarity search:
            #   1. Embeds the query into a vector
            #   2. Finds the top-k most similar chunks in FAISS
            #   3. Returns those Document objects
            docs = retriever.invoke(query)

            if not docs:
                return "No relevant information found in the resume for that query."

            # Concatenate the retrieved chunks into one block of context
            context_parts = []
            for i, doc in enumerate(docs, 1):
                page_info = doc.metadata.get("page", "?")
                context_parts.append(
                    f"[Excerpt {i} — Page {page_info}]\n{doc.page_content.strip()}"
                )

            return "\n\n".join(context_parts)

        except Exception as e:
            return f"Resume search failed: {e}"

    return resume_search


# ─── Assemble All Tools ───────────────────────────────────────────────────────

def get_all_tools(retriever) -> list:
    """
    Returns the complete list of tools for the agent.
    Call this after initializing the RAG retriever.

    Args:
        retriever: FAISS retriever from rag.get_retriever()

    Returns:
        List of LangChain tool objects
    """
    resume_tool = create_resume_search_tool(retriever)

    tools = [
        resume_tool,   # RAG: searches your PDF resume
        calculator,    # Math calculations
        web_search,    # Live internet search
        wikipedia_search,  # Wikipedia lookup
    ]

    print(f"🔧  Loaded {len(tools)} tools: {[t.name for t in tools]}")
    return tools

# ─────────────────────────────────────────────────────────────────────────────
#  app.py  –  Streamlit Chat Interface for the Digital Twin
#
#  Streamlit lets us build a web app with pure Python — no HTML/CSS/JS needed!
#  Run it with:   streamlit run app.py
#
#  HOW STREAMLIT WORKS:
#  Every time a user interacts (types a message, clicks a button),
#  Streamlit re-runs the entire script from top to bottom.
#  We use st.session_state to persist data (like chat history) across reruns.
# ─────────────────────────────────────────────────────────────────────────────

import os
import streamlit as st

import config
from rag import initialize_rag, get_retriever
from tools import get_all_tools
from agent import build_agent, chat


# ─── Page Configuration ───────────────────────────────────────────────────────
# Must be the FIRST Streamlit call in the file

st.set_page_config(
    page_title=f"{config.YOUR_NAME} – Digital Twin",
    page_icon="🤖",
    layout="centered",
)


# ─── Custom CSS ───────────────────────────────────────────────────────────────

st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 12px;
        color: white;
        margin-bottom: 2rem;
        text-align: center;
    }
    .stChatMessage { margin-bottom: 0.5rem; }
    .tool-badge {
        background: #e8f4f8;
        border-left: 3px solid #2196F3;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        font-size: 0.85rem;
        color: #555;
        margin: 0.25rem 0;
    }
</style>
""", unsafe_allow_html=True)


# ─── Header ───────────────────────────────────────────────────────────────────

st.markdown(f"""
<div class="main-header">
    <h1>🤖 {config.YOUR_NAME}'s Digital Twin</h1>
    <p>{config.YOUR_TAGLINE}</p>
    <small>Powered by Groq · LangChain · RAG</small>
</div>
""", unsafe_allow_html=True)


# ─── Sidebar: Upload & Controls ───────────────────────────────────────────────

with st.sidebar:
    st.header("⚙️ Setup")

    # File uploader for the resume PDF
    uploaded_file = st.file_uploader(
        "📄 Upload your Resume PDF",
        type=["pdf"],
        help="Your PDF will be processed into a local knowledge base.",
    )

    st.divider()

    st.subheader("🔧 Tools Available")
    st.markdown("""
    - 📋 **Resume Search** (RAG)
    - 🧮 **Calculator**
    - 🌐 **Web Search** (DuckDuckGo)
    - 📖 **Wikipedia**
    """)

    st.divider()

    # Button to reset the conversation
    if st.button("🗑️ Clear Conversation", use_container_width=True):
        st.session_state.messages = []
        # Remove agent from session so it gets rebuilt fresh
        if "agent" in st.session_state:
            del st.session_state["agent"]
        st.rerun()

    st.divider()

    # Show config info (hide API key)
    st.caption(f"Model: `{config.GROQ_MODEL}`")
    api_status = "✅ Set" if config.GROQ_API_KEY else "❌ Missing"
    st.caption(f"Groq API Key: {api_status}")


# ─── Session State Initialization ─────────────────────────────────────────────
# st.session_state persists values across Streamlit reruns within a session.
# Think of it as a per-user dictionary that survives page interactions.

if "messages" not in st.session_state:
    # Chat history: list of {"role": "user"/"assistant", "content": "..."}
    st.session_state.messages = []

if "agent" not in st.session_state:
    st.session_state.agent = None  # will be initialized below

if "pdf_processed" not in st.session_state:
    st.session_state.pdf_processed = False


# ─── Agent Initialization ─────────────────────────────────────────────────────

def initialize_agent(pdf_path: str):
    """
    Builds the full agent pipeline:
    PDF → RAG → Retriever → Tools → Agent
    Shows a spinner while loading.
    """
    with st.spinner("🔄 Processing PDF and building knowledge base..."):
        try:
            # Step 1: Build vector store from PDF
            vector_store = initialize_rag(pdf_path=pdf_path)

            # Step 2: Wrap it in a retriever
            retriever = get_retriever(vector_store)

            # Step 3: Create all tools (including the RAG tool)
            tools = get_all_tools(retriever)

            # Step 4: Build and return the agent
            agent = build_agent(tools)
            return agent

        except Exception as e:
            st.error(f"❌ Failed to initialize agent: {e}")
            return None


# ─── Handle PDF Upload ────────────────────────────────────────────────────────

if uploaded_file is not None and not st.session_state.pdf_processed:
    # Save the uploaded file to disk temporarily
    # (Streamlit gives us a file-like object; we save it as a real file)
    pdf_path = f"uploaded_resume_{uploaded_file.name}"

    with open(pdf_path, "wb") as f:
        f.write(uploaded_file.getvalue())

    st.sidebar.success(f"✅ Uploaded: {uploaded_file.name}")

    # Initialize the agent with the uploaded PDF
    agent = initialize_agent(pdf_path)

    if agent:
        st.session_state.agent = agent
        st.session_state.pdf_processed = True

        # Greet the user
        greeting = (
            f"Hello! I'm {config.YOUR_NAME}'s digital twin 🤖\n\n"
            f"I've loaded the resume and I'm ready to chat. You can ask me:\n"
            f"- About my skills, experience, and education\n"
            f"- To help with calculations\n"
            f"- To search the web for you\n"
            f"- To explain any topic\n\n"
            f"What would you like to know?"
        )
        st.session_state.messages.append({"role": "assistant", "content": greeting})
        st.rerun()

elif not uploaded_file and st.session_state.agent is None:
    # Try loading from an existing vector store (if the user already processed a PDF)
    try:
        from rag import load_vector_store
        vector_store = load_vector_store()
        if vector_store:
            with st.spinner("Loading existing knowledge base..."):
                retriever = get_retriever(vector_store)
                tools = get_all_tools(retriever)
                st.session_state.agent = build_agent(tools)
                st.session_state.pdf_processed = True
    except Exception:
        pass  # No existing store yet — user needs to upload PDF


# ─── No PDF Yet — Show Instructions ──────────────────────────────────────────

if not st.session_state.pdf_processed and uploaded_file is None:
    st.info(
        "👈 **Get started:** Upload your resume PDF in the sidebar to activate your Digital Twin.\n\n"
        "Your PDF is processed locally — nothing is sent to external servers except the LLM queries."
    )

    # Show example questions the agent can answer
    st.subheader("💡 Example Questions You Can Ask:")
    examples = [
        "Tell me about your experience.",
        "What programming languages do you know?",
        "What's 18% tip on a $75 dinner?",
        "Search the web for the latest trends in AI.",
        "What is LangChain?",
    ]
    for ex in examples:
        st.markdown(f"- _{ex}_")


# ─── Chat Interface ───────────────────────────────────────────────────────────

# Display all previous messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input box at the bottom
if prompt := st.chat_input(
    "Ask me anything...",
    disabled=(st.session_state.agent is None),
):
    # 1. Show the user's message immediately
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # 2. Get the agent's response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = chat(st.session_state.agent, prompt)
        st.markdown(response)

    # 3. Save the assistant's response to history
    st.session_state.messages.append({"role": "assistant", "content": response})


# ─── Footer ───────────────────────────────────────────────────────────────────

st.divider()
st.caption(
    "Built with ❤️ using LangChain · Groq · FAISS · Streamlit  |  "
    "Digital Twin Hackathon Project"
)
